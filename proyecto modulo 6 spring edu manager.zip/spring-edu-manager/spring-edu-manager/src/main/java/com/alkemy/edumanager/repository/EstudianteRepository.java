package com.alkemy.edumanager.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alkemy.edumanager.model.Estudiante;

public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {
}