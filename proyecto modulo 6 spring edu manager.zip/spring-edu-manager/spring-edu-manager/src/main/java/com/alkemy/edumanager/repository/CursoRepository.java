package com.alkemy.edumanager.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alkemy.edumanager.model.Curso;

public interface CursoRepository extends JpaRepository<Curso, Long> {
}