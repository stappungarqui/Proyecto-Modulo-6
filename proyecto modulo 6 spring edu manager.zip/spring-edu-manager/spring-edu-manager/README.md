# SpringEduManager 🎓

Sistema Web de Gestión Educativa para administrar Cursos y Estudiantes, desarrollado con Spring Boot, Spring Data JPA, Thymeleaf y Bootstrap 5.

## 🚀 Tecnologías Utilizadas
* **Lenguaje:** Java 17
* **Framework:** Spring Boot 3.2.3
* **Persistencia:** Spring Data JPA / Hibernate
* **Base de Datos:** H2 Database (En memoria)
* **Motor de Plantillas:** Thymeleaf
* **Frontend:** Bootstrap 5
* **Seguridad:** Spring Security (Configurado para acceso de desarrollo)

## 🛠️ Requisitos Previos
* Java Development Kit (JDK) 17 o superior.
* Maven (incluido mediante `./mvnw`).

## ⚙️ Instrucciones de Ejecución

1. Clonar el repositorio:
   ```bash
   git clone <URL_DE_TU_REPOSITORIO>
   cd spring-edu-manager