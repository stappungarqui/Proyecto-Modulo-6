package com.alkemy.edumanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEduManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
